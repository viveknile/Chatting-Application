# Chat-appliacation-using-JAVA-Socket-Programming
Java Chat application Using Sockets .

Remember, Start first Server app to create port than Client app to join it. It might possible that sometimes the port created by Server is Busy, then you have to change it by opening the Server and Client file.


#FEATURES  

	- able to perform conversion betwn Client and Server on Single Machine offfline


#APPLICATION DEVELOPE BY 

	- Java Socket Programming 

	- Netbeans IDE (8.1v)
